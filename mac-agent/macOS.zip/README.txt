Change environment variables in the run.sh file
Then ./run.sh