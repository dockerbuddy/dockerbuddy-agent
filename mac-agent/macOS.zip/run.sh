#!/bin/bash

export AGENT_HOST_ID="143c148e-d1ad-4274-8137-e74a832a453f"
export AGENT_BACKEND_ENDPOINT="http://ec2-18-170-40-205.eu-west-2.compute.amazonaws.com/api/v2/metrics"
export AGENT_FETCH_FREQ="10"

./agent