#!/bin/bash

export AGENT_HOST_ID="0ce50bc2"
export AGENT_BACKEND_ENDPOINT="http://localhost:8080/api/v2/metrics"
export AGENT_FETCH_FREQ="10"

./agent